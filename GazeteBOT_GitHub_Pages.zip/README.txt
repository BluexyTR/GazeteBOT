GazeteBOT GitHub Pages sitesi

1. GitHub'da public bir repository oluşturun (ör. gazetebot).
2. Bu ZIP içindeki index.html, terms.html ve privacy.html dosyalarını repository'nin kök dizinine yükleyin.
3. Settings > Pages bölümünde Deploy from a branch seçin.
4. Branch olarak main, folder olarak /(root) seçip Save'e basın.
5. Yayınlandıktan sonra adresleriniz şu biçimde olur:
   https://KULLANICIADI.github.io/gazetebot/
   https://KULLANICIADI.github.io/gazetebot/terms.html
   https://KULLANICIADI.github.io/gazetebot/privacy.html

Discord Developer Portal:
- Terms of Service URL: https://KULLANICIADI.github.io/gazetebot/terms.html
- Privacy Policy URL: https://KULLANICIADI.github.io/gazetebot/privacy.html

ÖNEMLİ:
Bu metinler yayın öncesi taslaktır. Gizlilik politikasındaki veri türleri ve saklama uygulamaları,
botun güncel kodu, logları ve yedekleriyle doğrulanmalıdır. İletişim/işletmeci bilgilerini ekleyin.
